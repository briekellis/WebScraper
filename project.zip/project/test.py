from bs4 import BeautifulSoup
import requests
import json 


url = 'https://www.addictinggames.com/funny-games/index.jsp'
response = requests.get(url, timeout=5)
content = BeautifulSoup(response.content, "html.parser")
gamesArr = []

for title in content.findAll('div', attrs={"class": "inn_box_panel1_box"}):
    gameObject = {
        "Title": title.find('div', attrs={"class": "txt_box"}).text,
        "VideoLink": title.find('div', attrs={"class": "video-thumb-link"}).text              
    }
    gamesArr.append(gameObject)


f = open('data.txt', "w+")

with open('twitterData.json', 'w') as outfile:
    json.dump(gamesArr, outfile)

with open('twitterData.json') as json_data:
    jsonData = json.load(json_data)

for i in jsonData:
    f.write("Title: " +  i["Title"].strip() + "\n" +
     "Video: " + i["VideoLink"].strip() + "\n\n") 

f.close()